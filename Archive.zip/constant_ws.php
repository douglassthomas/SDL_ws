<?php
    date_default_timezone_set("Asia/Bangkok");
    define("HOST", "127.0.0.1");
    define("DB", "sdl");
    define("USER", "root");
    define("PASSWORD", "");
    define("DOCUMENT_BASE_PATH", "../storage/");